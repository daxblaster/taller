
package vistas;

import bd.Conexion;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.Statement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class clientes extends javax.swing.JFrame {

    Conexion conexion=new Conexion("cadena_taller");
Statement st;
ResultSet rs;
DefaultTableModel modelo;
int id;

    public clientes() {
        initComponents();
        setLocationRelativeTo(null);
        listar();
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaclientes = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        txtnombre = new javax.swing.JTextField();
        txtapellido = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txttelefono = new javax.swing.JTextField();
        txtdpi = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txtidtaller = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        btnagregar = new javax.swing.JButton();
        btnmodificar = new javax.swing.JButton();
        btneliminar = new javax.swing.JButton();
        btnnuevo = new javax.swing.JButton();
        btnmenu = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder("Lista"));

        tablaclientes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "id", "nombre", "apellido", "telefono", "dpi", "id_taller"
            }
        ));
        jScrollPane1.setViewportView(tablaclientes);
        if (tablaclientes.getColumnModel().getColumnCount() > 0) {
            tablaclientes.getColumnModel().getColumn(0).setMinWidth(50);
            tablaclientes.getColumnModel().getColumn(0).setMaxWidth(50);
        }

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 466, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 198, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 8, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 432, -1, -1));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Cliente");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(157, 21, -1, -1));

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("Datos"));

        jLabel2.setText("id");

        jLabel3.setText("nombre");

        jLabel4.setText("apellido");

        jTextField1.setEnabled(false);

        jLabel5.setText("telefono");

        jLabel6.setText("dpi");

        jLabel7.setText("id taller");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5)
                    .addComponent(jLabel6)
                    .addComponent(jLabel7))
                .addGap(26, 26, 26)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtidtaller)
                    .addComponent(txtdpi)
                    .addComponent(jTextField1)
                    .addComponent(txtnombre)
                    .addComponent(txtapellido, javax.swing.GroupLayout.DEFAULT_SIZE, 288, Short.MAX_VALUE)
                    .addComponent(txttelefono))
                .addContainerGap(102, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(9, 9, 9)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtnombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(6, 6, 6)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txtapellido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txttelefono, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtdpi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtidtaller, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7))
                .addContainerGap(16, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 75, 488, -1));

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("Op"));

        btnagregar.setText("Agregar");
        btnagregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnagregarActionPerformed(evt);
            }
        });

        btnmodificar.setText("Modificar");

        btneliminar.setText("Eliminar");

        btnnuevo.setText("Nuevo");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(btnagregar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnmodificar)
                .addGap(43, 43, 43)
                .addComponent(btneliminar)
                .addGap(47, 47, 47)
                .addComponent(btnnuevo)
                .addGap(34, 34, 34))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnagregar)
                    .addComponent(btnmodificar)
                    .addComponent(btneliminar)
                    .addComponent(btnnuevo))
                .addContainerGap(40, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 303, 494, -1));

        btnmenu.setBackground(new java.awt.Color(153, 51, 0));
        btnmenu.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnmenu.setForeground(new java.awt.Color(255, 255, 255));
        btnmenu.setText("Menu");
        btnmenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnmenuActionPerformed(evt);
            }
        });
        getContentPane().add(btnmenu, new org.netbeans.lib.awtextra.AbsoluteConstraints(185, 691, 127, 50));

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/bd/imagen/23379.jpg"))); // NOI18N
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 500, 780));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnmenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnmenuActionPerformed

        menu newframe = new menu();
    newframe.setVisible(true);
    this.dispose();
        
        // TODO add your handling code here:
    }//GEN-LAST:event_btnmenuActionPerformed

    private void btnagregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnagregarActionPerformed

        // Aquí llamas al método agregarDatos con los datos que deseas insertar
        String nombre = txtnombre.getText(); // Reemplaza textFieldNombre con tu campo de texto real
        String apellido = txtapellido.getText(); // Reemplaza textFieldApellido con tu campo de texto real
        int telefono = Integer.parseInt(txttelefono.getText()); // Reemplaza textFieldTelefono con tu campo de texto real
        int dpi = Integer.parseInt(txtdpi.getText()); // Reemplaza textFieldDPI con tu campo de texto real
        int id_taller = Integer.parseInt(txtidtaller.getText()); // Reemplaza textFieldIdTaller con tu campo de texto real

        agregarDatos(nombre, apellido, telefono, dpi, id_taller);

    }//GEN-LAST:event_btnagregarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(clientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(clientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(clientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(clientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new clientes().setVisible(true);
            }
        });
    }

    void listar(){

    Conexion conexion=new Conexion("cadena_taller");
    String sql="select * from cliente";
    try{
    
        //cn=conexion.conectar();
        st=conexion.conectar().createStatement();
        rs=st.executeQuery(sql);
        Object[]clientes=new Object[6];
        modelo=(DefaultTableModel)tablaclientes.getModel();
       while(rs.next()){
       clientes[0]=rs.getInt("id");
       clientes[1]=rs.getString("nombre");
       clientes[2]=rs.getString("apellido");
       clientes[3]=rs.getInt("telefono");
       clientes[4]=rs.getInt("dpi");
       clientes[5]=rs.getInt("id_taller");
       modelo.addRow(clientes);
       }
       tablaclientes.setModel(modelo);
    }catch (Exception e){
    
    }
    
}
    void agregarDatos(String nombre, String apellido, int telefono, int dpi, int id_taller) {
    String sql = "INSERT INTO cliente (nombre, apellido, telefono, dpi, id_taller) VALUES (?, ?, ?, ?, ?)";
    Conexion conexion = new Conexion("cadena_taller");

    try {
        Connection connection = conexion.conectar();
        PreparedStatement pstmt = connection.prepareStatement(sql);
        
        // Establece los valores de los parámetros en la sentencia SQL
        pstmt.setString(1, nombre);
        pstmt.setString(2, apellido);
        pstmt.setInt(3, telefono);
        pstmt.setInt(4, dpi);
        pstmt.setInt(5, id_taller);
        
        // Ejecuta la sentencia SQL para agregar el nuevo cliente
        pstmt.executeUpdate();
        JOptionPane.showMessageDialog(null, "Agregado!");
        listarClientes();
        // Cierra la conexión
        pstmt.close();
        connection.close();
        
        // Proporciona retroalimentación al usuario si es necesario
        // Por ejemplo: JOptionPane.showMessageDialog(null, "Cliente agregado correctamente");
        
    } catch (SQLException e) {
        // Manejo de excepciones en caso de error
        e.printStackTrace();
    }
}
    String bd = "cadena_taller";
    String url = "jdbc:mysql://localhost:3306/";
    String user = "root";
    String password = "1234";
    String driver ="com.mysql.cj.jdbc.Driver";
    Connection cx;

    public Connection conectar(){
        try {
            Class.forName(driver);
            cx=DriverManager.getConnection(url+bd,user,password);
                        System.out.println("SE CONECTO A: "+bd);
        } catch (ClassNotFoundException | SQLException ex) {
            System.out.println("NO SE CONECTA A LA BASE DE DATOS: "+bd);
            //Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
        return cx;
    }
// Método para listar los datos de la tabla 'cliente' en el JTable
void listarClientes() {
    Connection conexion = null;
    Statement st = null;
    ResultSet rs = null;

    // Nombre de la tabla en la base de datos
    String nombreTabla = "cliente";

    // Consulta SQL para seleccionar todos los registros de la tabla 'cliente'
    String sql = "SELECT * FROM " + nombreTabla;

    try {
        // Obtener la conexión a la base de datos (ya debe estar configurada)
        conexion = conectar();  // Reemplaza 'TuClase' con el nombre de tu clase
        
        // Crear una declaración SQL
        st = conexion.createStatement();

        // Ejecutar la consulta SQL
        rs = st.executeQuery(sql);

        // Limpiar el modelo de la tabla antes de agregar nuevos datos
        modelo.setRowCount(0);

        // Array para almacenar los datos de un registro
        Object[] cliente = new Object[6];

        // Iterar a través de los resultados y agregarlos a la tabla
        while (rs.next()) {
            cliente[0] = rs.getInt("id");
            cliente[1] = rs.getString("nombre");
            cliente[2] = rs.getString("apellido");
            cliente[3] = rs.getInt("telefono");
            cliente[4] = rs.getLong("dpi");  // Usar long para DPI
            cliente[5] = rs.getInt("id_taller");

            // Agregar el registro a la tabla
            modelo.addRow(cliente);
        }

        // Actualizar el modelo de la tabla
        tablaclientes.setModel(modelo);

    } catch (Exception e) {
        e.printStackTrace();  // Manejo de errores
    } finally {
        // Cerrar recursos
        try {
            if (rs != null) rs.close();
            if (st != null) st.close();
            if (conexion != null) conexion.close();
        } catch (Exception e) {
            e.printStackTrace();  // Manejo de errores
        }
    }
}

    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnagregar;
    private javax.swing.JButton btneliminar;
    private javax.swing.JButton btnmenu;
    private javax.swing.JButton btnmodificar;
    private javax.swing.JButton btnnuevo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTable tablaclientes;
    private javax.swing.JTextField txtapellido;
    private javax.swing.JTextField txtdpi;
    private javax.swing.JTextField txtidtaller;
    private javax.swing.JTextField txtnombre;
    private javax.swing.JTextField txttelefono;
    // End of variables declaration//GEN-END:variables
}
