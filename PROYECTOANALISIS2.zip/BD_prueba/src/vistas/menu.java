
package vistas;


public class menu extends javax.swing.JFrame {

    public menu() {
        initComponents();
                    setLocationRelativeTo(null);

    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnusuarios = new javax.swing.JButton();
        btnciudaddes = new javax.swing.JButton();
        btnclientes = new javax.swing.JButton();
        btnestado = new javax.swing.JButton();
        btndetallefactura = new javax.swing.JButton();
        btnfactura = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        btnempleados = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnusuarios.setBackground(new java.awt.Color(204, 51, 0));
        btnusuarios.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnusuarios.setForeground(new java.awt.Color(255, 255, 255));
        btnusuarios.setText("usuarios");
        btnusuarios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnusuariosActionPerformed(evt);
            }
        });
        getContentPane().add(btnusuarios, new org.netbeans.lib.awtextra.AbsoluteConstraints(38, 117, 105, 56));

        btnciudaddes.setBackground(new java.awt.Color(204, 51, 0));
        btnciudaddes.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnciudaddes.setForeground(new java.awt.Color(255, 255, 255));
        btnciudaddes.setText("ciudades");
        btnciudaddes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnciudaddesActionPerformed(evt);
            }
        });
        getContentPane().add(btnciudaddes, new org.netbeans.lib.awtextra.AbsoluteConstraints(187, 117, 106, 56));

        btnclientes.setBackground(new java.awt.Color(204, 51, 0));
        btnclientes.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnclientes.setForeground(new java.awt.Color(255, 255, 255));
        btnclientes.setText("clientes");
        btnclientes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnclientesActionPerformed(evt);
            }
        });
        getContentPane().add(btnclientes, new org.netbeans.lib.awtextra.AbsoluteConstraints(347, 117, 109, 56));

        btnestado.setBackground(new java.awt.Color(204, 51, 0));
        btnestado.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnestado.setForeground(new java.awt.Color(255, 255, 255));
        btnestado.setText("estado");
        btnestado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnestadoActionPerformed(evt);
            }
        });
        getContentPane().add(btnestado, new org.netbeans.lib.awtextra.AbsoluteConstraints(486, 117, 108, 56));

        btndetallefactura.setBackground(new java.awt.Color(204, 204, 0));
        btndetallefactura.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btndetallefactura.setForeground(new java.awt.Color(51, 102, 0));
        btndetallefactura.setText("detalle factura");
        btndetallefactura.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btndetallefacturaActionPerformed(evt);
            }
        });
        getContentPane().add(btndetallefactura, new org.netbeans.lib.awtextra.AbsoluteConstraints(38, 220, -1, 63));

        btnfactura.setBackground(new java.awt.Color(204, 204, 0));
        btnfactura.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnfactura.setForeground(new java.awt.Color(51, 102, 0));
        btnfactura.setText("factura");
        btnfactura.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnfacturaActionPerformed(evt);
            }
        });
        getContentPane().add(btnfactura, new org.netbeans.lib.awtextra.AbsoluteConstraints(187, 220, 106, 63));

        jButton1.setBackground(new java.awt.Color(255, 204, 0));
        jButton1.setFont(new java.awt.Font("Segoe UI Historic", 1, 18)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("Log in");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(557, 419, -1, -1));

        btnempleados.setBackground(new java.awt.Color(204, 204, 0));
        btnempleados.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnempleados.setForeground(new java.awt.Color(0, 102, 0));
        btnempleados.setText("empleados");
        btnempleados.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnempleadosActionPerformed(evt);
            }
        });
        getContentPane().add(btnempleados, new org.netbeans.lib.awtextra.AbsoluteConstraints(347, 223, 110, 60));

        jButton2.setBackground(new java.awt.Color(204, 204, 0));
        jButton2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton2.setForeground(new java.awt.Color(51, 102, 0));
        jButton2.setText("metodo pago");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(486, 222, 110, 61));

        jButton3.setBackground(new java.awt.Color(102, 0, 0));
        jButton3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton3.setForeground(new java.awt.Color(255, 255, 255));
        jButton3.setText("Taller");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(38, 326, 105, 62));

        jButton4.setBackground(new java.awt.Color(102, 0, 0));
        jButton4.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton4.setForeground(new java.awt.Color(255, 255, 255));
        jButton4.setText("orden servicio");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(187, 326, 110, 62));

        jButton5.setBackground(new java.awt.Color(102, 0, 0));
        jButton5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton5.setForeground(new java.awt.Color(255, 255, 255));
        jButton5.setText("pais");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(347, 326, 98, 62));

        jButton6.setBackground(new java.awt.Color(102, 0, 0));
        jButton6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton6.setForeground(new java.awt.Color(255, 255, 255));
        jButton6.setText("repuesto");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(486, 326, 108, 62));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("MENU");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(264, 23, -1, -1));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/bd/imagen/SERVICAR(1)(1).png"))); // NOI18N
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 920, 510));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnusuariosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnusuariosActionPerformed
        // TODO add your handling code here:
        
        usuarios newframe = new usuarios();
    newframe.setVisible(true);
    this.dispose();
    }//GEN-LAST:event_btnusuariosActionPerformed

    private void btnciudaddesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnciudaddesActionPerformed

        ciudades newframe = new ciudades();
    newframe.setVisible(true);
    this.dispose();


        // TODO add your handling code here:
    }//GEN-LAST:event_btnciudaddesActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed

        login newframe = new login();
    newframe.setVisible(true);
    this.dispose();

        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    private void btnestadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnestadoActionPerformed

        estado newframe = new estado();
    newframe.setVisible(true);
    this.dispose();

        // TODO add your handling code here:
    }//GEN-LAST:event_btnestadoActionPerformed

    private void btnempleadosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnempleadosActionPerformed


        empleados newframe = new empleados();
    newframe.setVisible(true);
    this.dispose();
    
        // TODO add your handling code here:
    }//GEN-LAST:event_btnempleadosActionPerformed

    private void btnclientesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnclientesActionPerformed

        clientes newframe = new clientes();
    newframe.setVisible(true);
    this.dispose();
        
        // TODO add your handling code here:
    }//GEN-LAST:event_btnclientesActionPerformed

    private void btndetallefacturaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btndetallefacturaActionPerformed

        detalle_factura newframe = new detalle_factura();
    newframe.setVisible(true);
    this.dispose();

        // TODO add your handling code here:
    }//GEN-LAST:event_btndetallefacturaActionPerformed

    private void btnfacturaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnfacturaActionPerformed

        factura newframe = new factura();
    newframe.setVisible(true);
    this.dispose();

        // TODO add your handling code here:
    }//GEN-LAST:event_btnfacturaActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed

        metodo_pago newframe = new metodo_pago();
    newframe.setVisible(true);
    this.dispose();

        // TODO add your handling code here:
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed

        Taller newframe = new Taller();
    newframe.setVisible(true);
    this.dispose();

        // TODO add your handling code here:
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed

        orden_servicio newframe = new orden_servicio();
    newframe.setVisible(true);
    this.dispose();

        // TODO add your handling code here:
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed

        pais newframe = new pais();
    newframe.setVisible(true);
    this.dispose();
        
// TODO add your handling code here:
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed

        repuestos newframe = new repuestos();
    newframe.setVisible(true);
    this.dispose();

        // TODO add your handling code here:
    }//GEN-LAST:event_jButton6ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new menu().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnciudaddes;
    private javax.swing.JButton btnclientes;
    private javax.swing.JButton btndetallefactura;
    private javax.swing.JButton btnempleados;
    private javax.swing.JButton btnestado;
    private javax.swing.JButton btnfactura;
    private javax.swing.JButton btnusuarios;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    // End of variables declaration//GEN-END:variables
}
